package com.example.uuk2024_rendi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private int[]tombolNumeric = {R.id.tombolnol,R.id.tombolsatu,
            R.id.tomboldua, R.id.tomboltiga, R.id.tombolempat,R.id.tombollima,R.id.tombolenap,R.id.tomboltujuh,R.id.tomboldelapan,R.id.tombolsembilan};
    private int[]tombolOperator = {R.id.tombolkali,R.id.tombolbagi,R.id.tombolkurang,R.id.tomboltambah};
    private TextView layartampil;
    private TextView layarhasil;
    private boolean angkaTerahir;
    private  boolean kaloError;
    private boolean setelahTitik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.layartampil = (TextView) findViewById(R.id.Layartampil);
        this.layarhasil = (TextView) findViewById(R.id.Layarhasil);
        setNumericpadaSaatDiklik();
        setOperatorpadaSaatDiklik();





    }

    private void setOperatorpadaSaatDiklik() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button tombol = (Button) v;
                if (kaloError) {
                    layartampil.setText(tombol.getText());
                    kaloError = false;
                } else {
                    layartampil.append(tombol.getText());
                }
                angkaTerahir = true;
            }
        };
        for (int id : tombolNumeric) {
            findViewById(id).setOnClickListener(listener);
        }
    }



    private void setNumericpadaSaatDiklik() {
        View.OnClickListener listener =new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (angkaTerahir && !kaloError) {
                    Button tombol = (Button) v;
                    layartampil.append(tombol.getText());
                    angkaTerahir = false;
                    setelahTitik = false;
                }
            }
        };
        for (int id : tombolOperator) {
            findViewById(id).setOnClickListener(listener);
        }
        findViewById(R.id.tomboltitik).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (angkaTerahir && !kaloError && !setelahTitik) {
                    layartampil.append(".");
                    angkaTerahir = false;
                    setelahTitik = true;
                }
            }
        });
        findViewById(R.id.tombolc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layartampil.setText("");//BERSIHKAN LAYAR
                layarhasil.setText("");//BERSIHKAN LAYAR
                angkaTerahir  = false;
                kaloError = false;
                setelahTitik = false;
            }
        });
        findViewById(R.id.tombolsamadengan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onEqual();
            }

            private void onEqual() {
                if (angkaTerahir && !kaloError) {
                    String txt = layartampil.getText().toString();
                    Expression expression = new ExpressionBuilder(txt).build();
                    try {
                        double result = expression.evaluate();
                        layarhasil.setText(Double.toString(result));
                        setelahTitik = true;
                    } catch (ArithmeticException ex) {
                        layarhasil.setText("ERROR mas");
                        kaloError = true;
                        angkaTerahir = false;
                    }
                }
            }

        });
    }
}